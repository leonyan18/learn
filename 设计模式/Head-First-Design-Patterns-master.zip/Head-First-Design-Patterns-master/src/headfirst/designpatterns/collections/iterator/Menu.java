package headfirst.designpatterns.collections.iterator;

public interface Menu {
	public Iterator createIterator();
}
